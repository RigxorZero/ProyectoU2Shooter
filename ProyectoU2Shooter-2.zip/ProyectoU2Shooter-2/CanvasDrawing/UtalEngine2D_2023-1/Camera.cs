﻿
namespace CanvasDrawing.UtalEngine2D_2023_1
{
    public class Camera
    {
        public int xSize = 1920;
        public int ySize = 1080;
        public Vector2 Position;
        public float scale = 1;
    }
}
