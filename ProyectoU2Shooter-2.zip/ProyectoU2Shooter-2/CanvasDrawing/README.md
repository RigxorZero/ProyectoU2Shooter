# Laboratorio U2

Se utilizo como base el proyecto realizado en la unidad uno y como base el Engine realizado en clases.

## Integrantes

Hector Villalobos

Antonia Donoso

## Pantallas

Para crear las pantallas se crearon clases que se hacen cargo de presentar las nuevas pantallas para el juego

## Reinicio

Se creo la clase GameInitializer que se encarga de iniciar todas las instancias dentro del juego
